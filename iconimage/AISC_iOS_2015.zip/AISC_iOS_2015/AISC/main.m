//
//  main.m
//  AISC
//
//  Created by Zach Whelchel on 11/17/14.
//  Copyright (c) 2014 AISC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
