//
//  ContactsCell.m
//  AISC
//
//  Created by Zach Whelchel on 11/18/14.
//  Copyright (c) 2014 AISC. All rights reserved.
//

#import "ContactsCell.h"

@implementation ContactsCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
