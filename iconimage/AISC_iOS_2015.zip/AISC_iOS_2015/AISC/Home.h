//
//  Home.h
//  AISCH
//
//  Created by on 17/02/14.
//  Copyright (c) 2014 Angel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home : UIViewController {
    
    
    IBOutlet UIButton  *notificationButton;
}

-(IBAction)notificationView:(id)sender;
@end
